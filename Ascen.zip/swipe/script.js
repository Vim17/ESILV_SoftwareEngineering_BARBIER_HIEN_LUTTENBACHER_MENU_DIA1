const swiper = document.querySelector('#swiper');
const like = document.querySelector('#like');
const dislike = document.querySelector('#dislike');

const urls = [
  'image_s/Carte1.jpg',
  'image_s/Carte2.jpg',
  'image_s/Carte3.jpg',
  'image_s/Carte4.jpg',
  'image_s/Carte5.jpg',
  'image_s/Carte6.jpg',
  'image_s/Carte7.jpg',
  'image_s/Carte8.jpg',
  'image_s/Carte9.jpg',
  'image_s/Carte10.jpg'
];

let cardCount = 0;

function appendNewCard() {
  const card = new Card({
    imageUrl: urls[cardCount % 10],
    onDismiss: appendNewCard,
    onLike: () => {
      like.style.animationPlayState = 'running';
      like.classList.toggle('trigger');
    },
    onDislike: () => {
      dislike.style.animationPlayState = 'running';
      dislike.classList.toggle('trigger');
    }
  });
  swiper.append(card.element);
  cardCount++;
  const cards = swiper.querySelectorAll('.card:not(.dismissing)');
  cards.forEach((card, index) => {
    card.style.setProperty('--i', index);
  });
}

for (let i = 0; i < 5; i++) {
  appendNewCard();
}

